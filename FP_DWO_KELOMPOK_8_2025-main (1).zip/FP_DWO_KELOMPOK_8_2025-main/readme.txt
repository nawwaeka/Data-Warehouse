# FP_DWO_KELOMPOK8-2025
## Final Project Pengembangan Data Warehouse & Dashboard  
**Kelas Paralel C – Tahun 2025**

---

## 📌 Deskripsi Project
Aplikasi ini merupakan **Final Project mata kuliah Pengembangan Data Warehouse dan Dashboard**  
dengan studi kasus **AdventureWorks**, mencakup proses **ETL, Data Warehouse, OLAP (Mondrian)**, serta **Dashboard Visualisasi Data** berbasis web.

Project ini bertujuan untuk membantu analisis data penjualan, customer, produk, dan shipment secara multidimensi.

---

## 👥 Tim Pengembang – Kelompok 8
**Paralel C (2025)**

Hanim Rachma Nur Haliza	NPM. 22082010010
Medica N Zakiah			NPM. 22082010203
Eka Rahma Risnawati		NPM. 22082010218
Fathoni Adi Nugroho		NPM. 22082010252 

---

## 🛠️ Teknologi yang Digunakan
- **MySQL**
- **XAMPP** (Apache, MySQL, Tomcat)
- **phpMyAdmin**
- **Mondrian OLAP**
- **JSP & XML**
- **HTML, CSS, JavaScript**
- **Chart.js**

📘 Panduan Instalasi & Konfigurasi Sistem
Dokumen ini berisi langkah-langkah teknis untuk melakukan instalasi dan konfigurasi proyek FP_DWO_KELOMPOK_8-2025. Harap ikuti instruksi di bawah ini secara berurutan untuk memastikan aplikasi berjalan dengan lancar.

Sebelum memulai, pastikan komputer Anda telah terinstal XAMPP versi terbaru yang mencakup modul-modul berikut:

Apache Web Server
MySQL Database
Tomcat Server (Wajib diinstal/diaktifkan saat instalasi XAMPP)

langkah-Langkah Instalasi

1. Setup Source Code
Unduh atau Clone repositori ini dari GitHub.
Pindahkan folder hasil ekstrak ke dalam direktori htdocs pada instalasi XAMPP Anda.
Lokasi: C:\xampp\htdocs\FP_DWO_KELOMPOK_8-2025

2. Konfigurasi Database
Buka aplikasi XAMPP Control Panel.
Klik tombol Start pada modul Apache dan MySQL.
Buka browser dan akses phpMyAdmin: http://localhost/phpmyadmin.
Buat database baru dengan nama:"uas"
Pilih database uas yang baru dibuat, lalu masuk ke tab Import.
Pilih file SQL database bernama uas.sql  dalam folder proyek dan klik Import/Go.

3. Konfigurasi Server OLAP (Mondrian/Tomcat)
Langkah ini diperlukan untuk menghubungkan visualisasi OLAP dengan server Tomcat.
Pastikan modul Tomcat sudah terinstal di XAMPP.

Setup Query Files:

Cari file .jsp dan .xml dwoadw1.xml, dwoadw2.xml di dalam folder OLAP pada source code proyek.
Salin dan pindahkan file tersebut ke direktori server: C:\xampp\tomcat\webapps\mondrian\WEB-INF\queries

Setup Interface Files:

Cari file testpage.jsp, index.jsp, dan index.html yang ada di folder mondrian pada source code proyek.
Salin dan pindahkan file tersebut ke direktori root aplikasi mondrian: C:\xampp\tomcat\webapps\mondrian

4. Menjalankan Aplikasi
Buka XAMPP Control Panel.
Pastikan ketiga service berikut berstatus Running (Hijau):

✅ Apache
✅ MySQL
✅ Tomcat

Buka browser Anda (Chrome/Firefox/Edge).

Akses URL aplikasi:
http://localhost/FP_DWO_KELOMPOK_8-2025
