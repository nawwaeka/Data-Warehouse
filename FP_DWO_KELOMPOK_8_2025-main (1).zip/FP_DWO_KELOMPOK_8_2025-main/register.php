<?php

session_start();
require_once "auth/config.php"; 

$success = null;
$error = null;

if (isset($_POST['register'])) {
    
    // 1. Sanitasi Input
    $username_input = mysqli_real_escape_string($conn, $_POST['username']);
    $password_input = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // 2. Validasi Input
    if (empty($username_input) || empty($password_input) || empty($confirm_password)) {
        $error = "Semua field harus diisi.";
    } elseif ($password_input !== $confirm_password) {
        $error = "Konfirmasi password tidak cocok.";
    } elseif (strlen($password_input) < 6) {
        $error = "Password minimal 6 karakter.";
    } else {
        
        // 3. Cek Ketersediaan Username
        $check_query = mysqli_query($conn, "SELECT id FROM users WHERE username='$username_input'");
        if (mysqli_num_rows($check_query) > 0) {
            $error = "Username '{$username_input}' sudah digunakan.";
        } else {
            
            // 4. Hash Password
            $hashed_password = password_hash($password_input, PASSWORD_DEFAULT);
            
            // 5. Query INSERT Akun Baru
            $sql = "INSERT INTO users (username, password) VALUES ('$username_input', '$hashed_password')";

            if (mysqli_query($conn, $sql)) {
                $success = "Registrasi berhasil! Anda dapat <a href='index.php' class='text-white' style='font-weight:600;'>Login sekarang</a>.";
            } else {
                $error = "Gagal menyimpan data ke database. Error: " . mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="img/bar-chart.png">
    <title>::Register DWO kel 8::</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        /* CSS DARI index.php di-paste di sini agar tampilan konsisten */
        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Poppins', sans-serif;
            overflow: hidden;
            background: linear-gradient(-45deg, #667eea, #764ba2, #6bdbf7, #7b42f5);
            background-size: 400% 400%;
            animation: gradientMove 10s ease infinite; 
        }

        .glass-card {
            width: 100%;
            max-width: 400px;
            padding: 40px 30px;
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.15); 
            backdrop-filter: blur(18px); 
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .register-title {
            color: #fff;
            font-weight: 600;
            font-size: 26px;
            text-align: center;
            margin-bottom: 25px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, .1);
        }

        .input-group {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 5px;
            transition: .3s;
        }

        .input-group:focus-within {
            background: rgba(255, 255, 255, .2);
            border-color: rgba(255, 255, 255, .5);
        }

        .input-group-text {
            background: transparent !important;
            border: none;
            color: #fff;
            padding-left: 15px;
            font-size: 1.2rem;
        }

        .form-control {
            background: transparent !important;
            border: none !important;
            color: #fff !important;
            box-shadow: none !important;
            font-size: 15px;
            height: 45px;
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, .7);
        }

        .btn-register {
            background: #fff;
            color: #764ba2;
            font-weight: 600;
            border-radius: 12px;
            padding: 12px;
            font-size: 16px;
            margin-top: 10px;
            transition: .3s;
            border: none;
        }

        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, .2);
            background: #f0f0f0;
        }

        .showpass {
            cursor: pointer;
            color: white;
            font-size: 18px;
            display: flex;
            align-items: center;
            padding-right: 10px;
        }

        .alert-custom {
            border: none;
            color: white;
            border-radius: 8px;
            padding: 10px;
            text-align: center;
            margin-bottom: 15px;
        }

        .alert-danger {
            background: rgba(255, 0, 0, 0.5) !important;
        }
        
        .alert-success {
            background: rgba(0, 255, 0, 0.5) !important;
        }

        input:-webkit-autofill,
        input:-webkit-autofill:hover,
        input:-webkit-autofill:focus {
            -webkit-text-fill-color: white !important;
            -webkit-box-shadow: 0 0 0px 1000px rgba(255, 255, 255, 0) inset !important;
            transition: background-color 5000s ease-in-out 0s;
        }
    </style>
</head>

<body>
    <div class="glass-card">
        <div class="register-title">REGISTRASI PENGGUNA</div>

        <?php if (isset($error)): ?>
            <div class="alert alert-custom alert-danger">
                <i class="bi bi-exclamation-triangle-fill me-2"></i><?= $error ?>
            </div>
        <?php elseif (isset($success)): ?>
            <div class="alert alert-custom alert-success">
                <i class="bi bi-check-circle-fill me-2"></i><?= $success ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="input-group mb-3">
                <span class="input-group-text"><i class="bi bi-person"></i></span>
                <input type="text" name="username" class="form-control" placeholder="Masukan Username" required autofocus 
                    value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>">
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                <input type="password" name="password" id="pass" class="form-control" placeholder="Masukan Password" required>
                <span class="showpass" onclick="togglePass('pass', 'icon-pass')">
                    <i id="icon-pass" class="bi bi-eye-slash"></i>
                </span>
            </div>

            <div class="input-group mb-4">
                <span class="input-group-text"><i class="bi bi-lock"></i></span>
                <input type="password" name="confirm_password" id="confirm_pass" class="form-control" placeholder="Konfirmasi Password" required>
                <span class="showpass" onclick="togglePass('confirm_pass', 'icon-confirm-pass')">
                    <i id="icon-confirm-pass" class="bi bi-eye-slash"></i>
                </span>
            </div>

            <button class="btn btn-register w-100" name="register">REGISTER</button>
        </form>
        
        <div class="mt-3 text-center">
            <small class="text-white">Sudah punya akun? 
                <a href="index.php" class="text-warning" style="text-decoration: none; font-weight: 600;">Login di sini</a>
            </small>
        </div>

    </div>

    <script>
        function togglePass(id_pass, id_icon) {
            let p = document.getElementById(id_pass);
            let icon = document.getElementById(id_icon);

            if (p.type === "password") {
                p.type = "text";
                icon.className = "bi bi-eye"; 
            } else {
                p.type = "password";
                icon.className = "bi bi-eye-slash";
            }
        }
    </script>
</body>

</html>