<?php
include "config.php";
header('Content-Type: application/json');

$type  = $_GET['type'] ?? 'all';
$year  = $_GET['year'] ?? '';
$month = $_GET['month'] ?? '';
$kurs  = 16000;

$where = " WHERE 1=1 ";
if ($year !== '') $where .= " AND d.calendarYear = '$year' ";
if ($month !== '' && $year !== '') $where .= " AND d.monthNumberOfYear = '$month' ";

$response = [];

// --- KPI ---
if ($type == 'all' || $type == 'kpi') {
    $sql = "SELECT SUM(f.salesAmount * $kurs) AS total_sales, SUM(f.quantitySold) AS total_qty,
            COUNT(*) AS total_trx, AVG(f.salesAmount * $kurs) AS avg_sales
            FROM factSales f JOIN dimtime d ON f.timeId = d.timeId $where";
    $q = mysqli_query($conn, $sql);
    $response['kpi'] = mysqli_fetch_assoc($q);
}

// --- TREND (4 Garis: 2011 - 2014) ---
if ($type == 'all' || $type == 'trend') {
    $response['trend'] = [
        'labels' => ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'],
        'datasets' => []
    ];
    
    $years = ['2011', '2012', '2013', '2014'];
    $colors = ['#4e73df', '#1cc88a', '#f6c23e', '#e74a3b']; // Biru, Hijau, Kuning, Merah

    foreach ($years as $index => $y) {
        $data_bulan = array_fill(0, 12, 0);
        $sql = "SELECT MONTH(d.fulldate) as bln, SUM(f.salesAmount * $kurs) AS total 
                FROM factSales f JOIN dimtime d ON f.timeId = d.timeId 
                WHERE YEAR(d.fulldate) = '$y' GROUP BY MONTH(d.fulldate)";
        $q = mysqli_query($conn, $sql);
        while($r = mysqli_fetch_assoc($q)) {
            $data_bulan[$r['bln']-1] = (float)$r['total'];
        }

        $response['trend']['datasets'][] = [
            'label' => "Tahun $y",
            'data' => $data_bulan,
            'borderColor' => $colors[$index],
            'backgroundColor' => 'transparent',
            'borderWidth' => 2,
            'pointRadius' => 4, 
            'pointBackgroundColor' => $colors[$index],
            'tension' => 0.3
        ];
    }
}

// --- PRODUCT (Berdasarkan Quantity Sold) ---
if ($type == 'all' || $type == 'product') {
    $response['product'] = ['labels' => [], 'data' => []];
    $sql = "SELECT p.productName AS label, SUM(f.quantitySold) AS value
            FROM factSales f 
            JOIN dimproduct p ON f.produkId = p.produkId
            JOIN dimtime d ON f.timeId = d.timeId 
            $where
            GROUP BY p.productName 
            ORDER BY value DESC LIMIT 5";
            
    $q = mysqli_query($conn, $sql);
    while ($r = mysqli_fetch_assoc($q)) {
        $response['product']['labels'][] = $r['label'];
        $response['product']['data'][] = (int)$r['value'];
    }
}

// --- TERRITORY ---
if ($type == 'all' || $type == 'territory') {
    $response['territory'] = ['labels' => [], 'data' => []];
    $sql = "SELECT st.territoryName AS label, SUM(f.salesAmount * $kurs) AS value
            FROM factSales f 
            JOIN dimsalesterritory st ON f.territoryId = st.territoryId
            JOIN dimtime d ON f.timeId = d.timeId $where
            GROUP BY st.territoryName 
            ORDER BY value DESC";
            
    $q = mysqli_query($conn, $sql);
    while ($r = mysqli_fetch_assoc($q)) {
        $response['territory']['labels'][] = $r['label'];
        $response['territory']['data'][] = (float)$r['value'];
    }
}

echo json_encode($response);