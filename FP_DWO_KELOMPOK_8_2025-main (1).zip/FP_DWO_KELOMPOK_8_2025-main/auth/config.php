<?php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "uas";

// Buat koneksi
$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksia
if (!$conn) {
    die("Gagal koneksi database: " . mysqli_connect_error());
}

function check_login($redirect_path = "index.php") {
    if (!isset($_SESSION['user'])) { 
        header("Location: " . $redirect_path);
        exit;
    }
}
?>