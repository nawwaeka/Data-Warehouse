<?php
include "config.php";
header('Content-Type: application/json');

// Kurs USD to IDR
$kurs = 16000;

// Ambil parameter tipe data
$type = $_GET['type'] ?? 'kpi';
$response = [];

/* 1. KPI DATA */
if ($type === 'kpi') {
    // Hitung semua metrik dengan kurs
    $sql = "SELECT 
                COUNT(*) as total_trx,
                COUNT(DISTINCT vendorId) as active_vendor,
                SUM(amount * $kurs) as total_pembelian_idr,
                SUM(amount) as total_pembelian_usd
            FROM factpurchase";

    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    // Pengiriman Dominan
    $sqlShip = "SELECT s.name 
                FROM factpurchase f 
                JOIN dimshipmethod s ON f.shipMethodId = s.shipMethodId 
                GROUP BY f.shipMethodId 
                ORDER BY COUNT(*) DESC LIMIT 1";
    $shipResult = mysqli_query($conn, $sqlShip);
    $shipRow = mysqli_fetch_assoc($shipResult);

    $response = [
        'total_pembelian' => (float)($row['total_pembelian_idr'] ?? 0),
        'total_pembelian_usd' => (float)($row['total_pembelian_usd'] ?? 0),
        'total_trx'       => (int)($row['total_trx'] ?? 0),
        'active_vendor'   => (int)($row['active_vendor'] ?? 0),
        'dominant_ship'   => $shipRow['name'] ?? '-'
    ];
}

/* 2. TREND CHART - Tren Pertumbuhan Nilai Pembelian Tahunan */ else if ($type === 'trend') {
    $years = ['2011', '2012', '2013', '2014'];
    $colors = ['#4e73df', '#1cc88a', '#f6c23e', '#e74a3b'];
    $datasets = [];

    foreach ($years as $index => $yr) {
        $monthlyData = array_fill(0, 12, 0);

        $sql = "SELECT MONTH(fulldate) as bulan, 
                       COALESCE(SUM(f.amount * $kurs), 0) as total 
                FROM factpurchase f 
                JOIN dimtime t ON f.timeId = t.timeId 
                WHERE YEAR(t.fulldate) = '$yr' 
                GROUP BY MONTH(t.fulldate)
                ORDER BY bulan";

        $q = mysqli_query($conn, $sql);
        if ($q) {
            while ($r = mysqli_fetch_assoc($q)) {
                $bulanIndex = (int)$r['bulan'] - 1;
                if ($bulanIndex >= 0 && $bulanIndex < 12) {
                    $monthlyData[$bulanIndex] = (float)$r['total'];
                }
            }
        }

        $datasets[] = [
            'label' => "Tahun $yr",
            'data' => $monthlyData,
            'borderColor' => $colors[$index],
            'backgroundColor' => $colors[$index] . '20',
            'borderWidth' => 2,
            'fill' => true,
            'tension' => 0.4
        ];
    }

    $response = [
        'labels' => ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'],
        'datasets' => $datasets
    ];
}

/* 3. TOP 2 PRODUCTS - Performa Top 2 Produk */ else if ($type === 'product') {
    // Ambil top 2 produk berdasarkan total quantity
    $sqlTop2 = "SELECT p.productName, p.produkId, 
                       COALESCE(SUM(f.quantity), 0) as total_qty
                FROM factpurchase f
                JOIN dimproduct p ON f.produkId = p.produkId
                GROUP BY f.produkId, p.productName, p.produkId
                ORDER BY total_qty DESC 
                LIMIT 2";

    $qTop = mysqli_query($conn, $sqlTop2);
    $topProducts = [];

    if (!$qTop) {
        $response = [
            'labels' => ['2011', '2012', '2013', '2014'],
            'datasets' => []
        ];
    } else {
        while ($row = mysqli_fetch_assoc($qTop)) {
            $topProducts[] = $row;
        }

        if (empty($topProducts)) {
            $response = [
                'labels' => ['2011', '2012', '2013', '2014'],
                'datasets' => []
            ];
        } else {
            $years = ['2011', '2012', '2013', '2014'];
            $datasets = [];
            $colors = ['#4e73df', '#1cc88a'];

            foreach ($topProducts as $index => $prod) {
                $dataPerYear = [];
                foreach ($years as $yr) {
                    $pid = $prod['produkId'];
                    $sqlVal = "SELECT COALESCE(SUM(f.quantity), 0) as qty
                               FROM factpurchase f
                               JOIN dimtime t ON f.timeId = t.timeId
                               WHERE f.produkId = '$pid' AND YEAR(t.fulldate) = '$yr'";
                    $qVal = mysqli_query($conn, $sqlVal);

                    if ($qVal) {
                        $rVal = mysqli_fetch_assoc($qVal);
                        $dataPerYear[] = (int)($rVal['qty'] ?? 0);
                    } else {
                        $dataPerYear[] = 0;
                    }
                }

                $productName = $prod['productName'];
                if (strlen($productName) > 20) {
                    $productName = substr($productName, 0, 17) . '...';
                }

                $datasets[] = [
                    'label' => $productName,
                    'data' => $dataPerYear,
                    'backgroundColor' => $colors[$index],
                    'borderColor' => $colors[$index],
                    'borderWidth' => 1
                ];
            }

            $response = [
                'labels' => $years,
                'datasets' => $datasets
            ];
        }
    }
}

/* 4. VENDOR DISTRIBUTION - Distribusi Kontribusi Vendor Utama */ else if ($type === 'vendor') {
    $sql = "SELECT v.vendorName as label, COUNT(*) as value
            FROM factpurchase f
            JOIN dimvendor v ON f.vendorId = v.vendorId
            GROUP BY v.vendorId, v.vendorName
            ORDER BY value DESC 
            LIMIT 5";

    $q = mysqli_query($conn, $sql);
    $labels = [];
    $data = [];

    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $labels[] = $r['label'];
            $data[]   = (int)$r['value'];
        }
    }

    $response = [
        'labels' => $labels,
        'data' => $data
    ];
}

/* 5. SHIPPING METHOD COST  */ else if ($type === 'ship') {
    $sql = "SELECT s.name as label, 
                   COALESCE(SUM(f.amount * $kurs), 0) as value
            FROM factpurchase f
            JOIN dimshipmethod s ON f.shipMethodId = s.shipMethodId
            GROUP BY s.shipMethodId, s.name
            ORDER BY value DESC";

    $q = mysqli_query($conn, $sql);
    $labels = [];
    $data = [];

    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $labels[] = $r['label'];
            $data[]   = (float)$r['value'];
        }
    }

    $response = [
        'labels' => $labels,
        'data' => $data
    ];
} else {
    $response = ['error' => 'Invalid type parameter'];
}

echo json_encode($response);
mysqli_close($conn);
