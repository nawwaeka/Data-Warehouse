<%@ page session="true" contentType="text/html; charset=ISO-8859-1" %>
<%@ taglib uri="http://www.tonbeller.com/jpivot" prefix="jp" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jstl/core" %>

<jp:mondrianQuery id="query01"
    jdbcDriver="com.mysql.cj.jdbc.Driver"
    jdbcUrl="jdbc:mysql://localhost/uas?user=root&password="
    catalogUri="/WEB-INF/queries/dwoadw2.xml">



SELECT
    {
        [Measures].[Total Purchase Amount],
        [Measures].[Total Quantity Purchased],
        [Measures].[Purchase Transaction Count]
    } ON COLUMNS,

    NON EMPTY
    (
        [dimtime].[Full Date].Members
        *
        FILTER(
            [dimproduct].[Category].Members,
            [dimproduct].[Category].CurrentMember.Name <> "#null"
            AND [dimproduct].[Category].CurrentMember.Name <> "No Category"
        )
        *
        [dimvendor].[Vendor Name].Members
    ) ON ROWS

FROM [Purchase]


</jp:mondrianQuery>

<c:set var="title01" scope="session">Query FACT Purchase using Mondrian OLAP</c:set>
