<%@ page session="true" contentType="text/html; charset=ISO-8859-1" %>
<%@ taglib uri="http://www.tonbeller.com/jpivot" prefix="jp" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jstl/core" %>

<jp:mondrianQuery id="query01"
    jdbcDriver="com.mysql.cj.jdbc.Driver"
    jdbcUrl="jdbc:mysql://localhost/uas?user=root&password="
    catalogUri="/WEB-INF/queries/dwoadw1.xml">

SELECT 
  {[Measures].[Total Sales Amount], [Measures].[Total Quantity Sold]} ON COLUMNS,
  NON EMPTY
    (
      [dimtime].[fulldate].Members
      *
      [dimproduct].[Category].Members
    ) ON ROWS
FROM [Sales]


</jp:mondrianQuery>

<c:set var="title01" scope="session">Query Fact Sales using Mondrian OLAP</c:set>