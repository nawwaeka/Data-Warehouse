<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}
$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" href="../img/data-analysis.png">
    <title>Sales Dashboard</title>

    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900" rel="stylesheet">
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body id="page-top">

    <div id="wrapper">
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="../img/exploratory-analysis.png" style="width:78%">
                </div>
                <div class="sidebar-brand-text mx-3">KELOMPOK 8</div>
            </a>

            <hr class="sidebar-divider mt-2 mb-3">

            <li class="nav-item">
                <a class="nav-link custom-nav" href="dashboard.php ">
                    <i class="fas fa-fw fa-home"></i>
                    <span>Beranda</span>
                </a>
            </li>

            <li class="nav-item active">
                <a class="nav-link" href="sales_dashboard.php">
                    <i class="fas fa-fw fa-chart-bar"></i>
                    <span>Sales</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="purchase_dashboard.php">
                    <i class="fas fa-fw fa-shipping-fast"></i>
                    <span>Purchase</span>
                </a>
            </li>

            <hr class="sidebar-divider mt-3 mb-2">

            <div class="text-center d-none d-md-inline sidebar-toggle-wrapper">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>

        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <div class="d-none d-sm-inline-block mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-text text-dark">
                        <h5 class="m-0 text-dark font-weight-bold">FINAL PROJECT DATA WAREHOUSE </h5>
                    </div>
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item mx-1">
                            <a href="#" data-toggle="modal" data-target="#logoutModal"
                                class="btn btn-icon-split shadow-sm"
                                style="background-color: #f7a4a4; /* Merah Pastel Lebih Terang */border-color: #f59393;color: #fff; /* Warna Teks Putih */ border-radius: 10px;transition: all 0.2s; /* Tambahkan Transisi untuk Hover */ "
                                onmouseover="this.style.backgroundColor='#f48282'; this.style.borderColor='#f37676'; this.classList.add('shadow');"
                                onmouseout="this.style.backgroundColor='#f7a4a4'; this.style.borderColor='#f59393'; this.classList.remove('shadow');">
                                <span class="icon text-white-50">
                                    <i class="fas fa-sign-out-alt"></i>
                                </span>
                                <span class="text">Keluar</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="container-fluid">

                    <!-- KPI CARDS -->
                    <div class="row">

                        <!-- Total Sales -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Total Sales
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="totalSales">0</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Total Quantity -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Quantity Sold
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="totalQty">0</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-box fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Total Transaction -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                                Transactions
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="totalTrx">0</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-receipt fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Average Sales -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Avg Sales
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="avgSales">0</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <!-- END KPI  -->

                    <!-- CHART -->
                    <div class="container-fluid">
                        <div class="row" id="kpi-section">
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                                        <h6 class="m-0 font-weight-bold text-primary">
                                            <a href="#collapseTrend" class="text-decoration-none" data-toggle="collapse" role="button">
                                                <i class="fas fa-chevron-down mr-2"></i> Trend Penjualan berdasarkan tahun
                                            </a>
                                        </h6>
                                    </div>
                                    <div class="collapse" id="collapseTrend">
                                        <div class="card-body">
                                            <div style="height: 400px;">
                                                <canvas id="salesTrendChart"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-8 col-lg-7">
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                        <h6 class="m-0 font-weight-bold text-primary">
                                            <a href="#collapseProduct" class="text-decoration-none" data-toggle="collapse" role="button">
                                                <i class="fas fa-chevron-down mr-2"></i>
                                                Produk paling banyak terjual
                                            </a>
                                        </h6>
                                        <div class="dropdown no-arrow">
                                            <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                                                <div class="dropdown-header">Filter Tahun:</div>
                                                <a class="dropdown-item" href="#">Semua Tahun</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="#">2011</a>
                                                <a class="dropdown-item" href="#">2012</a>
                                                <a class="dropdown-item" href="#">2013</a>
                                                <a class="dropdown-item" href="#">2014</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="collapse" id="collapseProduct">
                                        <div class="card-body">
                                            <div style="height: 350px;">
                                                <canvas id="topProductChart"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4 col-lg-5">
                                <div class="card shadow mb-4">
                                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                        <h6 class="m-0 font-weight-bold text-primary">
                                            <a href="#collapseTerritory" class="text-decoration-none" data-toggle="collapse" role="button">
                                                <i class="fas fa-chevron-down mr-2"></i>
                                                Distribusi Penjualan tiap Wilayah
                                            </a>
                                        </h6>
                                        <div class="dropdown no-arrow">
                                            <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink2">
                                                <div class="dropdown-header">Filter Tahun:</div>
                                                <a class="dropdown-item" href="#">Semua Tahun</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="#">2011</a>
                                                <a class="dropdown-item" href="#">2012</a>
                                                <a class="dropdown-item" href="#">2013</a>
                                                <a class="dropdown-item" href="#">2014</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="collapse" id="collapseTerritory">
                                        <div class="card-body">
                                            <div style="height: 350px;">
                                                <canvas id="territoryChart"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END CHART  -->
                </div>
            </div>

            <footer class="sticky-footer bg-white">
                <div class="container my-auto text-center">
                    <span>Copyright © DWO Kelompok 8 2025</span>
                </div>
            </footer>

        </div>
    </div>

    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Konfirmasi Keluar</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    Klik <strong>"Keluar"</strong> di bawah jika Anda ingin mengakhiri sesi dan keluar dari sistem.
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    <a class="btn btn-danger" href="../auth/logout.php">Keluar</a>
                </div>
            </div>
        </div>
    </div>

    <!-- JS -->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../vendor/chart.js/Chart.min.js"></script>
    <script src="../js/sb-admin-2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@0.7.0"></script>
    <script src="../js/sales_dashboard.js"></script>

</body>

</html>