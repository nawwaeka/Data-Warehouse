<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}
$username = $_SESSION['username'];

// KONFIGURASI DATABASE LANGSUNG
$host = "localhost";
$user = "root";
$pass = "";
$db   = "uas";
$conn = mysqli_connect($host, $user, $pass, $db);

// LOGIKA HITUNG KPI (6 METRIK)
$kurs = 16000;

// 1. Sales KPI (Penjualan)
$qSales = mysqli_query($conn, "SELECT 
    SUM(salesAmount * $kurs) as total_revenue, 
    SUM(quantitySold) as total_qty_sold,
    COUNT(salesId) as total_trx_sales,
    AVG(salesAmount * $kurs) as avg_sales
    FROM factSales");
$dataSales = mysqli_fetch_assoc($qSales);

// 2. Purchase KPI (Pembelian)
$qPurch = mysqli_query($conn, "SELECT 
    SUM(amount * $kurs) as total_spend,
    SUM(quantity) as total_qty_purch
    FROM factPurchase");
$dataPurch = mysqli_fetch_assoc($qPurch);

// Fungsi Format Rupiah
function toIDR($angka)
{
    return "Rp " . number_format($angka, 2, ',', '.');
}

// Fungsi Format Angka Desimal/Unit
function toUnit($angka)
{
    return number_format($angka, 0, ',', '.') . " Unit";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" href="../img/data-analysis.png">
    <title>Beranda</title>

    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        .kpi-title {
            font-size: 0.7rem;
            font-weight: bold;
            text-transform: uppercase;
            color: #4e73df;
            margin-bottom: 5px;
        }

        .kpi-value {
            font-size: 1.1rem;
            font-weight: bold;
            color: #5a5c69;
        }

        .summary-box {
            background: #f8f9fc;
            border-left: 4px solid #4e73df;
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 5px;
        }
    </style>

</head>

<body id="page-top">

    <div id="wrapper">

        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="../img/exploratory-analysis.png" alt="Logo SPK" style="width: 78%; height: auto;">
                </div>
                <div class="sidebar-brand-text mx-3">KELOMPOK 8</div>
            </a>

            <hr class="sidebar-divider mt-2 mb-3">

            <li class="nav-item active">
                <a class="nav-link custom-nav" href="dashboard.php ">
                    <i class="fas fa-fw fa-home"></i>
                    <span>Beranda</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="sales_dashboard.php">
                    <i class="fas fa-fw fa-chart-bar"></i>
                    <span>Sales</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="purchase_dashboard.php">
                    <i class="fas fa-fw fa-shipping-fast"></i>
                    <span>Purchase</span>
                </a>
            </li>

            <hr class="sidebar-divider mt-3 mb-2">

            <div class="text-center d-none d-md-inline sidebar-toggle-wrapper">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <div id="content-wrapper" class="d-flex flex-column">

            <div id="content">
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <div class="d-none d-sm-inline-block mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-text text-dark">
                        <h5 class="m-0 text-dark font-weight-bold">FINAL PROJECT DATA WAREHOUSE </h5>
                    </div>
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item mx-1">
                            <a href="#" data-toggle="modal" data-target="#logoutModal"
                                class="btn btn-icon-split shadow-sm"
                                style="background-color: #f7a4a4; /* Merah Pastel Lebih Terang */border-color: #f59393;color: #fff; /* Warna Teks Putih */ border-radius: 10px;transition: all 0.2s; /* Tambahkan Transisi untuk Hover */ "
                                onmouseover="this.style.backgroundColor='#f48282'; this.style.borderColor='#f37676'; this.classList.add('shadow');"
                                onmouseout="this.style.backgroundColor='#f7a4a4'; this.style.borderColor='#f59393'; this.classList.remove('shadow');">
                                <span class="icon text-white-50">
                                    <i class="fas fa-sign-out-alt"></i>
                                </span>
                                <span class="text">Keluar</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="container-fluid">
                    <div class="mb-4">
                        <h3 class="h3 mb-0 text-gray-800">Selamat datang, <span class="text-primary font-weight-bold"><?php echo htmlspecialchars($username); ?></span></h3>
                        <p class="text-gray-600">SUMARY</p>
                    </div>

                    <div class="row">

                        <div class="row">
                            <div class="col-xl-4 col-md-6 mb-4">
                                <div class="card border-left-primary shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Penjualan (Revenue)</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo toIDR($dataSales['total_revenue']); ?></div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4 col-md-6 mb-4">
                                <div class="card border-left-success shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Kuantitas Terjual</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo toUnit($dataSales['total_qty_sold']); ?></div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-box-open fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4 col-md-6 mb-4">
                                <div class="card border-left-info shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Transaksi Penjualan</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format($dataSales['total_trx_sales'], 0, ',', '.'); ?> Trx</div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-receipt fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4 col-md-6 mb-4">
                                <div class="card border-left-warning shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Rata-rata Nilai Penjualan</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo toIDR($dataSales['avg_sales']); ?></div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4 col-md-6 mb-4">
                                <div class="card border-left-danger shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Total Biaya Pembelian (Spend)</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo toIDR($dataPurch['total_spend']); ?></div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-shopping-cart fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4 col-md-6 mb-4">
                                <div class="card border-left-secondary shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">Total Stok Masuk (Purchase)</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo toUnit($dataPurch['total_qty_purch']); ?></div>
                                            </div>
                                            <div class="col-auto">
                                                <i class="fas fa-truck-loading fa-2x text-gray-300"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="card shadow mb-4">
                        <a href="#collapseMondrian" class="card-header py-3 d-flex flex-row align-items-center justify-content-between bg-primary text-decoration-none collapsed" data-toggle="collapse" role="button" aria-expanded="false" aria-controls="collapseMondrian">
                            <h6 class="m-0 font-weight-bold text-white">
                                <i class="fas fa-database fa-sm fa-fw mr-2 text-white-50"></i>Analisis OLAP Mondrian
                            </h6>
                        </a>

                        <div class="collapse" id="collapseMondrian">
                            <div class="card-body p-0">
                                <div class="embed-responsive" style="height: 600px;">
                                    <iframe class="embed-responsive-item"
                                        src="http://localhost:8080/mondrian/index.html"
                                        allowfullscreen>
                                    </iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copyright text-center my-auto">
                            <span>Copyright DWO kelompok 8 2025 &copy;</span>
                        </div>
                    </div>
                </footer>
            </div>

        </div>
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Konfirmasi Keluar</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Klik <strong>"Keluar"</strong> di bawah jika Anda ingin mengakhiri sesi dan keluar dari sistem.
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                        <a class="btn btn-danger" href="../auth/logout.php">Keluar</a>
                    </div>
                </div>
            </div>
        </div>

</body>
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="../js/sb-admin-2.min.js"></script>

</html>