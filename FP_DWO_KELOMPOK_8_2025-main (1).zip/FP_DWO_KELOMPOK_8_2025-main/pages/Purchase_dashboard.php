<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}
$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" href="../img/data-analysis.png">
    <title>Purchase Dashboard</title>

    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body id="page-top">

    <div id="wrapper">

        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="../img/exploratory-analysis.png" alt="Logo SPK" style="width: 78%; height: auto;">
                </div>
                <div class="sidebar-brand-text mx-3">KELOMPOK 8</div>
            </a>

            <hr class="sidebar-divider mt-2 mb-3">

            <li class="nav-item">
                <a class="nav-link custom-nav" href="dashboard.php ">
                    <i class="fas fa-fw fa-home"></i>
                    <span>Beranda</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="sales_dashboard.php">
                    <i class="fas fa-fw fa-chart-bar"></i>
                    <span>Sales</span>
                </a>
            </li>

            <li class="nav-item active">
                <a class="nav-link" href="purchase_dashboard.php">
                    <i class="fas fa-fw fa-shipping-fast"></i>
                    <span>Purchase</span>
                </a>
            </li>

            <hr class="sidebar-divider mt-3 mb-2">

            <div class="text-center d-none d-md-inline sidebar-toggle-wrapper">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <div id="content-wrapper" class="d-flex flex-column">

            <div id="content">
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <div class="d-none d-sm-inline-block mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-text text-dark">
                        <h5 class="m-0 text-dark font-weight-bold">FINAL PROJECT DATA WAREHOUSE</h5>
                    </div>
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item mx-1">
                            <a href="#" data-toggle="modal" data-target="#logoutModal"
                                class="btn btn-icon-split shadow-sm"
                                style="background-color: #f7a4a4; /* Merah Pastel Lebih Terang */border-color: #f59393;color: #fff; /* Warna Teks Putih */ border-radius: 10px;transition: all 0.2s; /* Tambahkan Transisi untuk Hover */ "
                                onmouseover="this.style.backgroundColor='#f48282'; this.style.borderColor='#f37676'; this.classList.add('shadow');"
                                onmouseout="this.style.backgroundColor='#f7a4a4'; this.style.borderColor='#f59393'; this.classList.remove('shadow');">
                                <span class="icon text-white-50">
                                    <i class="fas fa-sign-out-alt"></i>
                                </span>
                                <span class="text">Keluar</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="container-fluid">

                    <!-- KPI CARDS -->
                    <div class="row">
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                        <i class="fas fa-shopping-cart mr-1"></i> Total Pembelian
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800" id="totalAmount">-</div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                        <i class="fas fa-exchange-alt mr-1"></i> Total Transaksi
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800" id="totalTrxPurchase">0</div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                        <i class="fas fa-building mr-1"></i> Vendor Aktif
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800" id="activeVendors">0</div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                        <i class="fas fa-truck mr-1"></i> Pengiriman Dominan
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800" id="dominantShip">-</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END KPI CARDS -->

                    <!-- Charts -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        <a href="#collapseSpendTrend" class="text-decoration-none" data-toggle="collapse" role="button">
                                            <i class="fas fa-chevron-down mr-2"></i> Tren Pertumbuhan Nilai Pembelian Tahunan
                                        </a>
                                    </h6>
                                </div>
                                <div class="collapse " id="collapseSpendTrend">
                                    <div class="card-body">
                                        <div style="height: 400px;">
                                            <canvas id="chartSpendTrend"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-xl-4 col-lg-7">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        <a href="#collapseTopItems" class="text-decoration-none" data-toggle="collapse" role="button">
                                            <i class="fas fa-chevron-down mr-2"></i> Performa Top 2 Produk
                                        </a>
                                    </h6>
                                </div>
                                <div class="collapse " id="collapseTopItems">
                                    <div class="card-body">
                                        <div style="height: 350px;">
                                            <canvas id="chartTopItems"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-5">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        <a href="#collapseVendor" class="text-decoration-none" data-toggle="collapse" role="button">
                                            <i class="fas fa-chevron-down mr-2"></i> Kontribusi top 5 Vendor terhadap Total Pembelian 
                                        </a>
                                    </h6>
                                </div>
                                <div class="collapse " id="collapseVendor">
                                    <div class="card-body">
                                        <div style="height: 350px;">
                                            <canvas id="chartVendorDist"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-5">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        <a href="#collapseShip" class="text-decoration-none" data-toggle="collapse" role="button">
                                            <i class="fas fa-chevron-down mr-2"></i> Variasi Metode Pengiriman Pembelian
                                        </a>
                                    </h6>
                                </div>
                                <div class="collapse " id="collapseShip">
                                    <div class="card-body">
                                        <div style="height: 320px;">
                                            <canvas id="chartShipVariation"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Charts -->

                </div>
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copyright text-center my-auto">
                            <span>Copyright DWO kelompok 8 2025 &copy;</span>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Konfirmasi Keluar</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Klik <strong>"Keluar"</strong> di bawah jika Anda ingin mengakhiri sesi dan keluar dari sistem.
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                        <a class="btn btn-danger" href="../auth/logout.php">Keluar</a>
                    </div>
                </div>
            </div>
        </div>
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="../vendor/chart.js/Chart.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@0.7.0"></script>
        <script src="../js/purchase_dashboard.js"></script>
        <script src="../js/sb-admin-2.min.js"></script>
</body>

</html>