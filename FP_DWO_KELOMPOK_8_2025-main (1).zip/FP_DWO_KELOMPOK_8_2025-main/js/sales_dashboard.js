var charts = {};

// Format Rupiah lengkap (untuk tooltip & detail)
const formatIDR = (val) => {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 2
    }).format(val);
};

// Format Rupiah ringkas (untuk KPI)
const shortIDR = (value) => {
    return "Rp " + Math.floor(value).toLocaleString('id-ID');
};

// Format angka biasa TANPA satuan juta/ribu
const shortNumber = (value) => {
    return Math.floor(value).toLocaleString('id-ID');
};

// Saat halaman siap
$(document).ready(function () {

    loadKPI();

    // Load chart hanya saat accordion dibuka (hemat performa)
    $('.collapse').on('shown.bs.collapse', function () {

        // Ambil ID accordion
        let id = $(this).attr('id');

        // Chart trend penjualan
        if (id === 'collapseTrend') {
            loadChart('trend', 'salesTrendChart', 'line');
        }

        // Chart top produk
        if (id === 'collapseProduct') {
            loadChart('product', 'topProductChart', 'bar');
        }

        // Chart wilayah penjualan
        if (id === 'collapseTerritory') {
            loadChart('territory', 'territoryChart', 'doughnut');
        }
    });
});

// Load KPI dari backend
function loadKPI() {
    $.ajax({
        url: "../auth/getdata_sales.php",
        method: "GET",
        data: { type: 'kpi' },
        success: function (res) {

            // Total penjualan 
            $("#totalSales").text(shortIDR(res.kpi.total_sales));

            // Total produk terjual
            $("#totalQty").text(shortNumber(res.kpi.total_qty) + " Terjual");

            // Total transaksi
            $("#totalTrx").text(shortNumber(res.kpi.total_trx) + " Transaksi");

            // Rata-rata penjualan per transaksi
            $("#avgSales").text(shortIDR(res.kpi.avg_sales) + " / Trx");
        }
    });
}

// Load data chart sesuai tipe
function loadChart(type, canvasId, kind) {
    $.ajax({
        url: "../auth/getdata_sales.php",
        method: "GET",
        data: { type: type },
        success: function (res) {

            // Chart trend punya handler khusus
            if (type === 'trend') {
                renderTrend(res.trend);
            }
            // Chart lain pakai fungsi umum
            else {
                renderSimple(canvasId, kind, res[type]);
            }
        }
    });
}

// Render chart trend penjualan tahunan
function renderTrend(data) {
    if (charts['trend']) charts['trend'].destroy();

    var ctx = document.getElementById('salesTrendChart').getContext('2d');
    charts['trend'] = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: data.datasets
        },
        options: {
            maintainAspectRatio: false,

            plugins: {
                datalabels: {
                    display: false
                }
            },

            legend: {
                display: true,
                position: 'bottom'
            },

            tooltips: {
                callbacks: {
                    label: function (tooltipItem, chartData) {
                        let label = chartData.datasets[tooltipItem.datasetIndex].label || '';
                        let value = tooltipItem.yLabel;
                        return label + ': ' + formatIDR(value);
                    }
                }
            },

            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true,
                        callback: function (value) {

                            if (value >= 1e12) {
                                return 'Rp ' + (value / 1e12).toFixed(2).replace('.', ',') + ' T';
                            }
                            if (value >= 1e9) {
                                return 'Rp ' + (value / 1e9).toFixed(2).replace('.', ',') + ' M';
                            }
                            if (value >= 1e6) {
                                return 'Rp ' + (value / 1e6).toFixed(2).replace('.', ',') + ' Jt';
                            }

                            return formatIDR(value);
                        }
                    }
                }]
            }
        }
    });
}


function generateColors(count) {
    const palette = [
        '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b',
        '#858796', '#fd7e14', '#20c9a6', '#6610f2', '#6f42c1',
        '#e83e8c', '#17a2b8', '#28a745', '#ffc107', '#343a40'
    ];

    let colors = [];
    for (let i = 0; i < count; i++) {
        colors.push(palette[i % palette.length]);
    }
    return colors;
}

// Render chart sederhana (bar & doughnut)
function renderSimple(canvasId, kind, data) {
    if (charts[canvasId]) charts[canvasId].destroy();

    var ctx = document.getElementById(canvasId).getContext('2d');

    // WARNA DINAMIS
    let borderColor;
    let borderWidth = 0;
    let bgColor;

    if (kind === 'doughnut' || kind === 'pie') {
        bgColor = generateColors(data.data.length);
    } else if (kind === 'bar') {
        bgColor = 'rgba(78, 115, 223, 0.55)';   
        borderColor = '#4e73df';            
        borderWidth = 2;
    }

    charts[canvasId] = new Chart(ctx, {
        type: kind,
        data: {
            labels: data.labels,
            datasets: [{
                label: (kind === 'bar') ? 'Jumlah Terjual' : 'Total Penjualan',
                data: data.data,
                backgroundColor: bgColor,
                borderColor: borderColor,
                borderWidth: borderWidth
            }]
        },
        options: {
            maintainAspectRatio: false,
            plugins: {
                datalabels: {
                    display: true,
                    color: '#fff',
                    font: {
                        weight: 'bold',
                        size: 11
                    },
                    formatter: (value, ctx) => {
                        // Jika Doughnut, tampilkan Persentase
                        if (kind === 'doughnut' || kind === 'pie') {
                            let sum = ctx.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                            let percentage = (value * 100 / sum).toFixed(1) + "%";
                            return percentage;
                        }
                        // Jika Bar, tampilkan Angka Biasa
                        return shortNumber(value);
                    },
                    // Sembunyikan jika nilainya 0
                    display: function(context) {
                        return context.dataset.data[context.dataIndex] > 0;
                    }
                }
            },

            legend: {
                display: (kind !== 'bar'),
                position: 'bottom'
            },

            tooltips: {
                callbacks: {
                    label: function (tooltipItem, chartData) {

                        let value = chartData.datasets[0].data[tooltipItem.index];
                        let label = chartData.labels[tooltipItem.index];

                        // BAR → QTY (TANPA RP)
                        if (kind === 'bar') {
                            return label + ': ' + shortNumber(value) + ' Terjual';
                        }

                        // DOUGHNUT / PIE → RUPIAH
                        return label + ': ' + formatIDR(value);
                    }
                }
            },

            scales: kind === 'bar' ? {
                yAxes: [{
                    ticks: {
                        beginAtZero: true,
                        callback: function (value) {
                            return shortNumber(value);
                        }
                    }
                }]
            } : {}
        }
    });
}