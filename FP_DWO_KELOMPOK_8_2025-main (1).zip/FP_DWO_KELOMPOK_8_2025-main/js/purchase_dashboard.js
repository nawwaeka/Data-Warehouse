var charts = {};

// Format Rupiah tanpa T/M/Jt, dengan 2 desimal
const formatIDRFull = (val) => {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(val);
};

// Format Rupiah untuk KPI (tanpa T/M/Jt, tanpa desimal)
const formatIDRKPI = (val) => {
    return 'Rp ' + Math.floor(val).toLocaleString('id-ID');
};

// Format angka biasa tanpa satuan
const shortNumber = (value) => {
    return Math.floor(value).toLocaleString('id-ID');
};

// Format persentase
const formatPercent = (value) => {
    return value.toFixed(1) + '%';
};

$(document).ready(function () {
    loadKPI();

    $('.collapse').on('shown.bs.collapse', function () {
        let id = $(this).attr('id');

        if (id === 'collapseSpendTrend') {
            loadChart('trend', 'chartSpendTrend', 'line');
        }
        if (id === 'collapseTopItems') {
            loadChart('product', 'chartTopItems', 'bar');
        }
        if (id === 'collapseVendor') {
            loadChart('vendor', 'chartVendorDist', 'doughnut');
        }
        if (id === 'collapseShip') {
            loadChart('ship', 'chartShipVariation', 'doughnut');
        }
    });
});

// Load KPI dari backend
function loadKPI() {
    $.ajax({
        url: "../auth/getdata_purchase.php",
        method: "GET",
        data: { type: 'kpi' },
        success: function (res) {
            console.log("KPI Data:", res);
            
            // Format total pembelian: "Rp 1.020.672.095.040,00"
            let totalPembelian = res.total_pembelian || 0;
            $("#totalAmount").text(formatIDRFull(totalPembelian));

            // Total transaksi (hanya angka)
            $("#totalTrxPurchase").text(shortNumber(res.total_trx));

            // Vendor aktif (hanya angka)
            $("#activeVendors").text(shortNumber(res.active_vendor));

            // Pengiriman dominan
            $("#dominantShip").text(res.dominant_ship || '-');
        },
        error: function(xhr, status, error) {
            console.error("Error loading KPI:", error);
        }
    });
}

// Load data chart
function loadChart(type, canvasId, kind) {
    console.log("Loading chart:", type, canvasId, kind);
    
    if (charts[canvasId]) {
        charts[canvasId].destroy();
    }

    $.ajax({
        url: "../auth/getdata_purchase.php",
        method: "GET",
        data: { type: type },
        success: function (res) {
            console.log(type + " Data:", res);
            
            if (type === 'trend') {
                renderTrend(res);
            } else if (type === 'product') {
                renderBarChart(canvasId, res);
            } else if (type === 'vendor') {
                renderDoughnutChart(canvasId, res, 'vendor');
            } else if (type === 'ship') {
                renderDoughnutChart(canvasId, res, 'ship');
            }
        },
        error: function(xhr, status, error) {
            console.error("Error loading chart:", error);
        }
    });
}

// Render trend chart
function renderTrend(data) {
    var ctx = document.getElementById('chartSpendTrend').getContext('2d');
    
    if (charts['chartSpendTrend']) {
        charts['chartSpendTrend'].destroy();
    }
    
    charts['chartSpendTrend'] = new Chart(ctx, {
        type: 'line',
        data: data,
        options: {
            maintainAspectRatio: false,
            
            plugins: {
                datalabels: {
                    display: false
                }
            },
            
            legend: {
                display: true,
                position: 'bottom'
            },
            
            tooltips: {
                callbacks: {
                    label: function (tooltipItem, chartData) {
                        let label = chartData.datasets[tooltipItem.datasetIndex].label || '';
                        let value = tooltipItem.yLabel;
                        return label + ': ' + formatIDRFull(value);
                    }
                }
            },
            
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true,
                        callback: function (value) {
                            return formatIDRFull(value);
                        }
                    }
                }],
                xAxes: [{
                    ticks: {
                        autoSkip: false,
                        maxRotation: 45
                    }
                }]
            }
        }
    });
}

// Render bar chart untuk top products
function renderBarChart(canvasId, data) {
    var ctx = document.getElementById(canvasId).getContext('2d');
    
    if (charts[canvasId]) {
        charts[canvasId].destroy();
    }
    
    // Warna untuk bar chart
    const colors = ['#4e73df', '#1cc88a'];
    
    // Siapkan data jika kosong
    if (!data.datasets || data.datasets.length === 0) {
        data = {
            labels: ['2011', '2012', '2013', '2014'],
            datasets: [{
                label: 'Tidak ada data',
                data: [0, 0, 0, 0],
                backgroundColor: '#858796',
                borderColor: '#858796',
                borderWidth: 1
            }]
        };
    } else {
        // Tambahkan warna ke setiap dataset
        data.datasets = data.datasets.map((dataset, index) => {
            return {
                ...dataset,
                backgroundColor: colors[index % colors.length],
                borderColor: colors[index % colors.length],
                borderWidth: 1
            };
        });
    }
    
    charts[canvasId] = new Chart(ctx, {
        type: 'bar',
        data: data,
        options: {
            maintainAspectRatio: false,
            
            plugins: {
                datalabels: {
                    display: true,
                    color: '#000',
                    font: {
                        weight: 'bold',
                        size: 11
                    },
                    anchor: 'end',
                    align: 'top',
                    formatter: function(value) {
                        return shortNumber(value);
                    },
                    display: function(context) {
                        return context.dataset.data[context.dataIndex] > 0;
                    }
                }
            },
            
            legend: {
                display: true,
                position: 'top'
            },
            
            tooltips: {
                callbacks: {
                    label: function (tooltipItem, chartData) {
                        let label = chartData.datasets[tooltipItem.datasetIndex].label || '';
                        let value = chartData.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
                        return label + ': ' + shortNumber(value) + ' unit';
                    }
                }
            },
            
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true,
                        callback: function (value) {
                            return shortNumber(value);
                        }
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'Jumlah Unit'
                    }
                }],
                xAxes: [{
                    scaleLabel: {
                        display: true,
                        labelString: 'Tahun'
                    }
                }]
            }
        }
    });
}

// Render doughnut chart untuk vendor dan shipping
function renderDoughnutChart(canvasId, data, chartType) {
    var ctx = document.getElementById(canvasId).getContext('2d');
    
    if (charts[canvasId]) {
        charts[canvasId].destroy();
    }
    
    // Warna untuk doughnut chart
    const colors = [
        '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b',
        '#858796', '#6f42c1', '#20c9a6', '#fd7e14', '#e83e8c'
    ];
    
    // Siapkan data jika kosong
    if (!data.data || data.data.length === 0) {
        data = {
            labels: ['Tidak ada data'],
            data: [1],
            backgroundColor: ['#858796']
        };
    }
    
    // Hitung total untuk persentase
    const total = data.data.reduce((sum, value) => sum + value, 0);
    
    // Buat data untuk chart
    const chartData = {
        labels: data.labels,
        datasets: [{
            data: data.data,
            backgroundColor: colors.slice(0, data.data.length),
            borderWidth: 1,
            borderColor: '#fff'
        }]
    };
    
    charts[canvasId] = new Chart(ctx, {
        type: 'doughnut',
        data: chartData,
        options: {
            maintainAspectRatio: false,
            cutoutPercentage: 60,
            
            plugins: {
                datalabels: {
                    display: true,
                    color: '#fff',
                    font: {
                        weight: 'bold',
                        size: chartType === 'vendor' ? 12 : 10
                    },
                    formatter: function(value, context) {
                        if (total === 0) return '0%';
                        const percentage = (value / total * 100).toFixed(1);
                        return percentage + '%';
                    },
                    textAlign: 'center',
                    padding: 4
                }
            },
            
            legend: {
                display: true,
                position: 'right',
                labels: {
                    boxWidth: 12,
                    padding: 15,
                    fontColor: '#333',
                    usePointStyle: true
                }
            },
            
            tooltips: {
                callbacks: {
                    label: function (tooltipItem, chartData) {
                        const label = chartData.labels[tooltipItem.index];
                        const value = chartData.datasets[0].data[tooltipItem.index];
                        const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : '0.0';
                        
                        if (chartType === 'vendor') {
                            return `${label}: ${shortNumber(value)} transaksi (${percentage}%)`;
                        } else if (chartType === 'ship') {
                            return `${label}: ${formatIDRFull(value)} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}