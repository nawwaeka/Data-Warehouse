<?php
session_start();

require_once "auth/config.php"; 

define('SESSION_TIMEOUT', 1800); 


function destroy_session_and_redirect($location = 'index.php') {
    session_unset();
    header("Location: " . $location); 
    exit;
}

if (isset($_SESSION['user_id'])) {

    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > SESSION_TIMEOUT)) {
        destroy_session_and_redirect();
    }
    $_SESSION['LAST_ACTIVITY'] = time(); 

    header("Location: dashboard.php");
    exit;
}

$error = null; 

if (isset($_POST['login'])) {

    $username_input = mysqli_real_escape_string($conn, $_POST['username']);

    $password_input = $_POST['password']; 

    $query = mysqli_query($conn, "SELECT id, username, password FROM users WHERE username='$username_input'");
    $user  = mysqli_fetch_assoc($query);

    if ($user) {
        if (password_verify($password_input, $user['password'])) {

            $_SESSION['user_id'] = $user['id']; 
            $_SESSION['username'] = $user['username']; 
            $_SESSION['LAST_ACTIVITY'] = time();
            
            header("Location: pages/dashboard.php");
            exit;
        }
    }

    $error = "Username atau password salah.";
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="img/exploratory-analysis.png">
    <title>::Login DWO kel 8::</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>

        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Poppins', sans-serif;
            overflow: hidden;
            background: linear-gradient(-45deg, #667eea, #764ba2, #6bdbf7, #7b42f5);
            background-size: 400% 400%;
            animation: gradientMove 10s ease infinite; /* Terapkan animasi */
        }

        .glass-card {
            width: 100%;
            max-width: 400px;
            padding: 40px 30px;
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.15); /* Transparan */
            backdrop-filter: blur(18px); /* Efek blur */
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .login-title {
            color: #fff;
            font-weight: 600;
            font-size: 26px;
            text-align: center;
            margin-bottom: 25px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, .1);
        }

        /* Styling Input Group */
        .input-group {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 5px;
            transition: .3s;
        }

        .input-group:focus-within {
            background: rgba(255, 255, 255, .2);
            border-color: rgba(255, 255, 255, .5);
        }

        .input-group-text {
            background: transparent !important;
            border: none;
            color: #fff;
            padding-left: 15px;
            font-size: 1.2rem;
        }

        .form-control {
            background: transparent !important;
            border: none !important;
            color: #fff !important;
            box-shadow: none !important;
            font-size: 15px;
            height: 45px;
        }

        .form-control::placeholder {
            color: rgba(255, 255, 255, .7);
        }

        .btn-login {
            background: #fff;
            color: #5b42f3;
            font-weight: 600;
            border-radius: 12px;
            padding: 12px;
            font-size: 16px;
            margin-top: 10px;
            transition: .3s;
            border: none;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, .2);
            background: #f0f0f0;
        }

        .showpass {
            cursor: pointer;
            color: white;
            font-size: 18px;
            display: flex;
            align-items: center;
            padding-right: 10px;
        }

        .alert-danger {
            background: rgba(255, 0, 0, 0.5) !important;
            border: none;
            color: white;
            border-radius: 8px;
            padding: 10px;
            text-align: center;
        }

        input:-webkit-autofill,
        input:-webkit-autofill:hover,
        input:-webkit-autofill:focus {
            -webkit-text-fill-color: white !important;
            -webkit-box-shadow: 0 0 0px 1000px rgba(255, 255, 255, 0) inset !important;
            transition: background-color 5000s ease-in-out 0s;
        }
    </style>
</head>

<body>
    <div class="glass-card">
        <div class="login-title">LOGIN PENGGUNA</div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger py-2 text-center mb-3">
                <i class="bi bi-exclamation-triangle-fill me-2"></i><?= $error ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="input-group mb-3">
                <span class="input-group-text"><i class="bi bi-person"></i></span>
                <input type="text" name="username" class="form-control" placeholder="Username" required autofocus>
            </div>

            <div class="input-group mb-4">
                <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                <input type="password" name="password" id="pass" class="form-control" placeholder="Password" required>
                <span class="showpass" onclick="togglePass()">
                    <i id="icon-pass" class="bi bi-eye-slash"></i>
                </span>
            </div>

            <button class="btn btn-login w-100" name="login">LOGIN</button>
    
        </form>

        <div class="mt-3 text-center">
            <small class="text-white">Belum punya akun? 
                <a href="register.php" class="text-warning" style="text-decoration: none; font-weight: 600;">Register di sini</a>
            </small>
        </div>

    </div>

    <script>
        function togglePass() {
            let p = document.getElementById("pass");
            let icon = document.getElementById("icon-pass");

            if (p.type === "password") {
                p.type = "text";
                icon.className = "bi bi-eye"; 
            } else {
                p.type = "password";
                icon.className = "bi bi-eye-slash";
            }
        }

        // Script untuk menghilangkan notifikasi error secara otomatis setelah 5 detik
        document.addEventListener('DOMContentLoaded', function() {
            const errorAlert = document.querySelector('.alert-danger');
            if (errorAlert) {
                errorAlert.style.transition = 'opacity 0.5s ease';

                setTimeout(() => {
                    errorAlert.style.opacity = '0';
                    setTimeout(() => {
                        errorAlert.remove();
                    }, 500);
                }, 5000); 
            }
        });
    </script>
</body>

</html>